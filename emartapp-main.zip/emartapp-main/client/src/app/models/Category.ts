export interface Category {
  id: string;
  cat_name: string;
  products: [object];
}
