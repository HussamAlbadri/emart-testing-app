package com.springwork.bookwork;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookWorkApplicationTests {

	@Test
	void contextLoads() {
	}

}
